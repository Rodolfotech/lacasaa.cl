<?php
/**
 * Plugin Name:       CASA A Panel
 * Description:       Login por JWT (correo + contraseña) y galería de imágenes por categorías, con edición y borrado. Shortcode [jwt_gallery] para el login y [jwt_gallery_panel] para el panel autenticado.
 * Version:           2.1.6
 * Requires at least: 6.0
 * Requires PHP:      7.2.24
 * Author:            CASA A
 * License:           GPL-2.0-or-later
 * Text Domain:       jwt-gallery
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'JG_VERSION', '2.1.6' );
define( 'JG_PATH', plugin_dir_path( __FILE__ ) );
define( 'JG_URL', plugin_dir_url( __FILE__ ) );

require_once JG_PATH . 'includes/class-jg-jwt.php';
require_once JG_PATH . 'includes/class-jg-rest.php';
require_once JG_PATH . 'includes/class-jg-cpt.php';
require_once JG_PATH . 'includes/class-jg-shortcode.php';
require_once JG_PATH . 'includes/class-jg-template.php';
require_once JG_PATH . 'includes/class-jg-settings.php';

// Catálogo de productos (antes plugin aparte casa-a-catalogo): va dentro de este mismo plugin.
require_once JG_PATH . 'includes/catalogo/catalogo.php';
require_once JG_PATH . 'includes/catalogo/sync-galeria.php';
require_once JG_PATH . 'includes/catalogo/espejo-categorias.php';
require_once JG_PATH . 'includes/catalogo/producto-extra.php';

JG_CPT::init();
JG_REST::init();
JG_Shortcode::init();
JG_Template::init();

// Pantalla de ajustes solo en el wp-admin (no altera el frontend).
if ( is_admin() ) {
	JG_Settings::register();
}

/**
 * Seguridad: deshabilitar XML-RPC.
 *
 * xmlrpc.php permite amplificación de brute-force vía system.multicall
 * (cientos de intentos de contraseña en una sola petición). El plugin no
 * usa la app móvil ni pingbacks, así que se deshabilita por completo.
 *
 * - El filtro devuelve false → WP responde 403 a toda petición a xmlrpc.php.
 * - pingback.ping se deshabilita al desactivar XML-RPC por completo.
 * - El REST API (wp-json) y los endpoints del plugin no se ven afectados.
 */
add_filter( 'xmlrpc_enabled', '__return_false' );
add_filter( 'xmlrpc_methods', '__return_empty_array' );

register_activation_hook(
	__FILE__,
	function () {
		JG_JWT::get_secret();
		JG_CPT::register();
		JG_CPT::seed_default_categories();
		casa_a_catalogo_register();
		flush_rewrite_rules();
	}
);

register_deactivation_hook( __FILE__, 'flush_rewrite_rules' );
